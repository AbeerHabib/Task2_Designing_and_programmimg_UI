<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="RobotArmControl.css"/>
<link rel="icon" sizes="32x32" href="robotic-arm.png"/>
<title>Robot Arm Control</title>
</head>

<body>
<header>

<section id="sec1">
<div id="div1">
<h1>Robot Arm Control Panel</h1>
<div>
</section>
</header>

<section id="sec2">
<form  action="connect.php" method="POST">

<div>
<p class="title"><b>Gripper:</b></p>
<p>0</p><input type="range" min="0" max="180" value="0" class="slider" id="myRange1" name="gripper"><p>180</p>
<div class="value"<p><span id="demo1"></span></p></div>
</div>

<div>
<p class="title"><b>Wrist 1:</b></p>
<p>0</p><input type="range" min="0" max="180" value="90" class="slider" id="myRange2" name="wrist1"><p>180</p>
<div class="value"<p><span id="demo2"></span></p></div>
</div>

<div>
<p class="title"><b>Wrist 2:</b></p>
<p>0</p><input type="range" min="0" max="180" value="90" class="slider" id="myRange3" name="wrist2"><p>180</p>
<div class="value"<p><span id="demo3"></span></p></div>
</div>

<div>
<p class="title"><b>Elbow:</b></p>
<p>0</p><input type="range" min="0" max="180" value="90" class="slider" id="myRange4" name="elbow"><p>180</p>
<div class="value"<p><span id="demo4"></span></p></div>
</div>

<div>
<p class="title"><b>Shoulder:</b></p>
<p>0</p><input type="range" min="0" max="180" value="90" class="slider" id="myRange5" name="shoulder"><p>180</p>
<div class="value"<p><span id="demo5"></span></p></div>
</div>

<div>
<p class="title"><b>Base:</b></p>
<p>0</p><input type="range" min="0" max="180" value="90" class="slider" id="myRange6" name="base"><p>180</p>
<div class="value"<p><span id="demo6"></span></p></div>
</div>

<div id="buttons">
<input class="button" id="save" type="submit" value="Save" name="save">
<input class="button" type="submit" value="Run" name="run">
</form>

</section>

<section id="sec3">
<div id="messagecontainer">
<p><span id="message"></span></p>
</div>
</section>

<script>
var slider1 = document.getElementById("myRange1");
var output1 = document.getElementById("demo1");
output1.innerHTML = slider1.value;

slider1.oninput = function() {
  output1.innerHTML = this.value;
}

var slider2 = document.getElementById("myRange2");
var output2 = document.getElementById("demo2");
output2.innerHTML = slider2.value;

slider2.oninput = function() {
  output2.innerHTML = this.value;
}

var slider3 = document.getElementById("myRange3");
var output3 = document.getElementById("demo3");
output3.innerHTML = slider3.value;

slider3.oninput = function() {
  output3.innerHTML = this.value;
}

var slider4 = document.getElementById("myRange4");
var output4 = document.getElementById("demo4");
output4.innerHTML = slider4.value;

slider4.oninput = function() {
  output4.innerHTML = this.value;
}

var slider5 = document.getElementById("myRange5");
var output5 = document.getElementById("demo5");
output5.innerHTML = slider5.value;

slider5.oninput = function() {
  output5.innerHTML = this.value;
}

var slider6 = document.getElementById("myRange6");
var output6 = document.getElementById("demo6");
output6.innerHTML = slider6.value;

slider6.oninput = function() {
  output6.innerHTML = this.value;
}


</script>

