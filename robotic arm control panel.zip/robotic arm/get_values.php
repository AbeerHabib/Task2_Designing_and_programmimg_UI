<?php

$conn = mysqli_connect('localhost','root','','robot_arm_control');

$sql = mysqli_query($conn,"SELECT * FROM robot_arm_control WHERE id=(SELECT MAX(id) FROM robot_arm_control)");

if($sql){	

   echo nl2br("Fetched data successfully ! \n"); 
   echo "<br>";
   
   while($row = mysqli_fetch_assoc($sql)) {

	  echo "Base="; echo $row['base'];
	  echo "<br>";
	  echo "Shoulder="; echo ($row['shoulder']);
	  echo "<br>";
	  echo "Elbow="; echo ($row['elbow']);
	  echo "<br>";
	  echo "Wrist1="; echo ($row['wrist1']);
	  echo "<br>";
	  echo "Wrist2="; echo ($row['wrist2']);
	  echo "<br>";
	  echo "Gripper="; echo ($row['gripper']);
	  echo "<br>";
	  echo "Status="; echo ($row['status']);	  
}
}

else{
	
	echo "Error.";
}

mysqli_close($conn);

?>