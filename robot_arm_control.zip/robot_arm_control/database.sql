-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 20 يونيو 2021 الساعة 21:33
-- إصدار الخادم: 10.4.17-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `robot arm control`
--

-- --------------------------------------------------------

--
-- بنية الجدول `robot_arm_control`
--

DROP TABLE IF EXISTS `robot_arm_control`;
CREATE TABLE `robot_arm_control` (
  `id` int(100) NOT NULL,
  `base` int(180) NOT NULL DEFAULT 90,
  `shoulder` int(180) NOT NULL DEFAULT 90,
  `elbow` int(180) NOT NULL DEFAULT 90,
  `wrist1` int(180) NOT NULL DEFAULT 90,
  `wrist2` int(180) NOT NULL DEFAULT 90,
  `gripper` int(180) NOT NULL DEFAULT 0,
  `status` varchar(3) COLLATE utf8mb4_bin NOT NULL DEFAULT 'off'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- إرجاع أو استيراد بيانات الجدول `robot_arm_control`
--

INSERT INTO `robot_arm_control` (`id`, `base`, `shoulder`, `elbow`, `wrist1`, `wrist2`, `gripper`, `status`) VALUES
(7, 77, 130, 53, 50, 90, 132, 'off'),
(8, 34, 76, 103, 177, 42, 132, 'off'),
(9, 109, 76, 42, 79, 126, 132, 'on');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `robot_arm_control`
--
ALTER TABLE `robot_arm_control`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `robot_arm_control`
--
ALTER TABLE `robot_arm_control`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
