<?php


$gripper = $_POST['gripper'];
$wrist1 = $_POST['wrist1'];
$wrist2 = $_POST['wrist2'];
$elbow = $_POST['elbow'];
$shoulder = $_POST['shoulder'];
$base = $_POST['base'];

$conn = mysqli_connect('localhost','root','','robot arm control');


if(isset($_POST['save'])){


$sql = mysqli_query($conn,"INSERT INTO robot_arm_control(base,shoulder,elbow,wrist1,wrist2,gripper) VALUES ('$base', '$shoulder', '$elbow', '$wrist1', '$wrist2',$gripper)");


if($sql){	
	echo "The data has been saved !";
}

else{
	
	echo "nothing was inserted into table.";
}

}

if(isset($_POST['run'])){

$sql = mysqli_query($conn,"UPDATE robot_arm_control SET status='on' WHERE base='$base' AND shoulder='$shoulder' AND elbow='$elbow' AND wrist1='$wrist1' AND wrist2='$wrist2' AND gripper='$gripper'");	
	
if($sql){	
	
	echo"in progress now...";

}

else{
	
	echo"Not working, there is an error.";
}

}	


mysqli_close($conn);

?>
